# Iberic Phone — ESX Legacy & QBCore

FiveM smartphone resource for **QBCore** and **ESX Legacy**.  
UI in **English** and **Spanish** (toggle inside the phone).

Version **1.2.0** · unified framework layer · no duplicate ESX/QB logic.

---

# Español

## 1. Requisitos

| Recurso | Obligatorio | Uso |
|---------|-------------|-----|
| `oxmysql` | Sí | Base de datos |
| `qb-core` **o** `es_extended` | Sí | Framework |
| `pma-voice` (u otro con `setPlayerCall`) | Recomendado | Audio de llamadas |
| `screenshot-basic` | Solo si usas Cámara | Subida de fotos |

Arranca **siempre** `oxmysql` y el framework **antes** de `iberic-phone`.

## 2. Instalación

1. Copia la carpeta `iberic-phone` a `resources/`.
2. Importa `sql/install.sql` en tu MySQL/MariaDB.
3. En `server.cfg`:
```cfg
ensure oxmysql
ensure qb-core          # o: ensure es_extended
ensure pma-voice        # recomendado
ensure screenshot-basic # si usas la cámara
ensure iberic-phone
```
4. Edita `config.lua` (framework, ítem, **API keys / webhooks**).
5. Asegúrate de que el ítem del teléfono exista en el inventario (`Config.PhoneItem`, por defecto `phone`).

## 3. API Keys / integraciones (cámara, voz, etc.)

Todo se configura en **`config.lua`**.

### Cámara (fotos → Galería) — Fivemanage

1. Instala y arranca **`screenshot-basic`** (antes de `iberic-phone`).
2. En [app.fivemanage.com](https://app.fivemanage.com/) crea un token de tipo **Images**.
3. Pon las keys en `config.lua`:

```lua
Config.UploadProvider = 'fivemanage'
Config.APIKeys = {
    images = 'TU_TOKEN_IMAGES',
    audio  = 'TU_TOKEN_AUDIO',   -- reservado
    video  = 'TU_TOKEN_VIDEO',   -- reservado
    logs   = 'TU_TOKEN_LOGS',    -- reservado
}
Config.FivemanageUploadUrl = 'https://api.fivemanage.com/api/v3/file'
Config.FivemanageField     = 'file'
```

**Cómo funciona:** la cámara usa `screenshot-basic` → sube a Fivemanage API v3 con tu token de imágenes → guarda la URL CDN en la galería.

Alternativa Discord: `Config.UploadProvider = 'discord'` + `Config.ScreenshotWebhook = 'https://discord.com/api/webhooks/...'`.

### Voz (llamadas)

```lua
Config.VoiceResource = 'pma-voice'  -- debe exportar setPlayerCall(source, channelId)
```

Sin un recurso de voz compatible, las llamadas “suenan” en la UI pero no hay canal de audio real.

### Otras claves (opcional / forks)

```lua
Config.APIKeys = {
    discord_webhook = '',  -- fallback de cámara
    -- fivemanage = '',    -- ejemplo para hosts de media personalizados
    -- imgur_client_id = '',
}
```

**No subas `config.lua` con webhooks reales a repositorios públicos.**

## 4. Abrir el teléfono

| Acción | Detalle |
|--------|---------|
| Tecla | **F1** (`Config.OpenKey`) — reasignable en Ajustes FiveM |
| Comandos | `/ibericphone` · `/phone` |
| Ítem | Si `Config.RequireItem = true`, hace falta el ítem `Config.PhoneItem` |

### Controles mientras está abierto

- Puedes **caminar / correr / mirar** (`SetNuiFocusKeepInput`).
- Ataque, apuntar y rueda de armas se bloquean.
- **U** — notificaciones  
- **T** — plegar / desplegar  
- **Y** — inicio  
- **ESC** — cerrar  
- **Alt izq** — cámara libre (modo cámara)

## 5. Framework (ESX + QBCore unificado)

```lua
Config.Framework = 'auto'  -- 'auto' | 'qb' | 'esx'
```

- `client/framework.lua` y `server/framework.lua` envuelven ESX con una API estilo QBCore.
- El resto del código **no** se duplica: un solo flujo para ambos.

**ESX**
- ID: `xPlayer.identifier`
- Teléfono: charinfo / columna `users.phone`
- Duty: opcional con `Config.ESXSetJobDuty = function(xPlayer, onDuty) ... end`
- Garaje: por defecto `owned_vehicles`; override con `Config.ESXGarageQuery`

**QBCore**
- Datos, dinero, jobs e ítems nativos de QBCore
- Garaje: schema típico `player_vehicles`

## 6. Aplicaciones y funciones

### Dock (barra inferior)

| Botón | Función |
|-------|---------|
| Phone | Llamadas, recientes, favoritos, teclado |
| Messages | SMS / hilos |
| Contacts | Contactos, favoritos, bloqueo |
| App Store | Instalar / desinstalar apps de tienda |
| Camera | Foto (requiere webhook + screenshot-basic) |
| **Torch** | Linterna real (spotlight desde el personaje) — **no es una app**, es un botón del dock |

### Parrilla (inicio)

| App | Función |
|-----|---------|
| Settings | Cuenta, privacidad, wallpapers, tema, modo avión, DND, 24h, unfold |
| Socials | Red social (posts, likes, etc.) |
| Garage | Vehículos, búsqueda, estado, combustible, motor, carrocería |
| Licenses | Permisos del jugador |
| Gallery | Fotos guardadas |
| Calendar | Eventos / recordatorios |
| Business | Trabajo, duty, sueldo, negocios propios |
| Crypto | Precios y compraventa de monedas configuradas |
| Bank | Saldo, transferencias por número de teléfono |
| Lemon List (Market) | Anuncios locales |
| Calculator | Calculadora básica |
| Services | Llama a un jugador **online + on duty** del job configurado |

### App Store (instalables)

Bank · Crypto · Market · Business · Services  

(Si no están instaladas, no aparecen en la parrilla.)

### Services (detalle)

```lua
Config.ServiceContacts = {
    police    = { label = 'Police',    job = 'police',    description = 'Police assistance' },
    sheriff   = { label = 'Sheriff',   job = 'sheriff',   description = 'Sheriff department' },
    ambulance = { label = 'Ambulance', job = 'ambulance', description = 'Medical emergency' },
}
```

1. El servidor busca jugadores con ese `job` y `onduty = true`.
2. Elige uno libre al azar.
3. Inicia una **llamada real** a su número de teléfono.

Si no hay unidades → *No hay unidades de servicio en este momento*.

### Linterna (dock)

- Alterna luz real (`DrawSpotLight` + fill) delante del personaje.
- El icono del dock se ilumina en ámbar cuando está activa.
- No depende de apps ni de webhooks.

### Cámara y Galería

1. Configura `Config.ScreenshotWebhook` (o `Config.APIKeys.discord_webhook`).
2. Arranca `screenshot-basic`.
3. Abre Camera → captura → la foto queda en Gallery y se puede adjuntar en mensajes.

### Llamadas y mensajes

- Llamadas: marcación, recientes, favoritos, silencio, altavoz (hook `Config.OnLoudspeaker`), retención, colgar.
- Mensajes: hilos, adjuntos de galería, ubicación, emojis, grupos (según datos del servidor).
- Contactos: alta, favoritos, bloquear, compartir número a jugadores cercanos (`Config.ShareDistance`).

### Banco / Crypto / Market / Business / News

- **Bank:** transferencias a número online; historial.
- **Crypto:** monedas en `Config.Crypto`; intervalo `Config.CryptoUpdateMinutes`.
- **Market:** anuncios; límite `Config.MaxMarketPosts`.
- **Business:** duty, negocios, empleados, contrataciones; límite `Config.MaxBusinesses`.
- **News:** publicar si el job está en `Config.NewsJobs`.

## 7. Idiomas

Botón **ES · EN** en la esquina del teléfono. Preferencia guardada en el navegador NUI.

## 8. Solución de problemas

| Problema | Qué revisar |
|----------|-------------|
| No abre | Ítem del teléfono, `Config.RequireItem`, consola cliente |
| SQL / callbacks fallan | `oxmysql` arrancado antes; `sql/install.sql` importado |
| Framework error | `Config.Framework` y que qb-core o es_extended estén started |
| Cámara no funciona | Webhook en `config.lua` + `screenshot-basic` started |
| Llamadas sin audio | `Config.VoiceResource` y export `setPlayerCall` |
| Services sin unidades | Job name exacto + jugadores on duty online |
| Errores `[iberic-phone]` | Consola servidor y cliente |

## 9. Crear una app (desarrolladores)

1. Entrada en `APPS` (`html/app.js`).
2. ID en `GRID` / `GRID_UNFOLD` o `DOCK`.
3. Renderer `R.miapp = () => ...`.
4. Acciones con `ACT.xxx` y `data-act`.
5. Traducciones EN/ES al final de `app.js`.
6. Datos persistentes: `CB('miapp:load', ...)` en `server/main.lua` + `api('miapp:load', ...)`.

**Nunca** confíes en citizenid, números, cantidades o jobs enviados solo desde la NUI: deriva la identidad del jugador en el servidor.

---

# English

## 1. Requirements

| Resource | Required | Purpose |
|----------|----------|---------|
| `oxmysql` | Yes | Database |
| `qb-core` **or** `es_extended` | Yes | Framework |
| `pma-voice` (or any with `setPlayerCall`) | Recommended | Call audio |
| `screenshot-basic` | Only for Camera | Photo upload |

Always start **oxmysql** and the framework **before** `iberic-phone`.

## 2. Installation

1. Copy `iberic-phone` into your `resources/` folder.
2. Import `sql/install.sql` into MySQL/MariaDB.
3. In `server.cfg`:
```cfg
ensure oxmysql
ensure qb-core          # or: ensure es_extended
ensure pma-voice        # recommended
ensure screenshot-basic # if you use the camera
ensure iberic-phone
```
4. Edit `config.lua` (framework, item, **API keys / webhooks**).
5. Ensure the phone inventory item exists (`Config.PhoneItem`, default `phone`).

## 3. API Keys / integrations (camera, voice, etc.)

Everything is set in **`config.lua`**.

### Camera (photos → Gallery) — Fivemanage

1. Install and start **`screenshot-basic`** (before `iberic-phone`).
2. At [app.fivemanage.com](https://app.fivemanage.com/) create an **Images** token.
3. Set keys in `config.lua`:

```lua
Config.UploadProvider = 'fivemanage'
Config.APIKeys = {
    images = 'YOUR_IMAGES_TOKEN',
    audio  = 'YOUR_AUDIO_TOKEN',
    video  = 'YOUR_VIDEO_TOKEN',
    logs   = 'YOUR_LOGS_TOKEN',
}
Config.FivemanageUploadUrl = 'https://api.fivemanage.com/api/v3/file'
Config.FivemanageField     = 'file'
```

**How it works:** Camera uses `screenshot-basic` → uploads to Fivemanage API v3 with your Images token → stores the CDN URL in the gallery.

Discord alternative: `Config.UploadProvider = 'discord'` + `Config.ScreenshotWebhook = 'https://discord.com/api/webhooks/...'`.

### Voice (calls)

```lua
Config.VoiceResource = 'pma-voice'  -- must export setPlayerCall(source, channelId)
```

Without a compatible voice resource, calls still ring in the UI but there is no real voice channel.

### Other keys (optional / forks)

```lua
Config.APIKeys = {
    discord_webhook = '',  -- camera fallback
    -- fivemanage = '',
    -- imgur_client_id = '',
}
```

**Do not commit real webhooks to public repositories.**

## 4. Opening the phone

| Action | Detail |
|--------|--------|
| Key | **F1** (`Config.OpenKey`) — rebindable in FiveM Settings |
| Commands | `/ibericphone` · `/phone` |
| Item | If `Config.RequireItem = true`, player must own `Config.PhoneItem` |

### Controls while open

- **Walk / run / look** remain available (`SetNuiFocusKeepInput`).
- Attack, aim and weapon wheel are blocked.
- **U** — notifications  
- **T** — fold / unfold  
- **Y** — home  
- **ESC** — close  
- **Left Alt** — free camera (camera mode)

## 5. Framework (unified ESX + QBCore)

```lua
Config.Framework = 'auto'  -- 'auto' | 'qb' | 'esx'
```

- `client/framework.lua` and `server/framework.lua` wrap ESX into a QBCore-style API.
- Application code is **not** duplicated: one path for both frameworks.

**ESX**
- ID: `xPlayer.identifier`
- Phone: charinfo / `users.phone`
- Duty: optional `Config.ESXSetJobDuty = function(xPlayer, onDuty) ... end`
- Garage: default `owned_vehicles`; override with `Config.ESXGarageQuery`

**QBCore**
- Native player data, money, jobs, usable items
- Garage: typical `player_vehicles` schema

## 6. Apps and features

### Dock (bottom bar)

| Button | Feature |
|--------|---------|
| Phone | Calls, recents, favourites, keypad |
| Messages | SMS / threads |
| Contacts | Contacts, favourites, block |
| App Store | Install / uninstall store apps |
| Camera | Photo (needs webhook + screenshot-basic) |
| **Torch** | Real flashlight (player spotlight) — **not an app**, dock control only |

### Home grid

| App | Feature |
|-----|---------|
| Settings | Account, privacy, wallpapers, theme, airplane, DND, 24h, unfold |
| Socials | Social feed (posts, likes, etc.) |
| Garage | Vehicles, search, status, fuel, engine, body |
| Licenses | Player licences |
| Gallery | Saved photos |
| Calendar | Events / reminders |
| Business | Job, duty, paycheck, owned businesses |
| Crypto | Configured coins; trade |
| Bank | Balance, transfers by phone number |
| Lemon List (Market) | Local listings |
| Calculator | Basic calculator |
| Services | Calls an **online + on-duty** player with the configured job |

### App Store (installable)

Bank · Crypto · Market · Business · Services  

(Hidden from the grid until installed.)

### Services (detail)

```lua
Config.ServiceContacts = {
    police    = { label = 'Police',    job = 'police',    description = 'Police assistance' },
    sheriff   = { label = 'Sheriff',   job = 'sheriff',   description = 'Sheriff department' },
    ambulance = { label = 'Ambulance', job = 'ambulance', description = 'Medical emergency' },
}
```

1. Server finds players with that `job` and `onduty = true`.
2. Picks one available unit at random.
3. Starts a **real phone call** to their number.

If none → *No units on duty right now*.

### Torch (dock)

- Toggles a real world light (`DrawSpotLight` + fill) in front of the player.
- Dock icon glows amber while active.
- No app entry and no webhook required.

### Camera & Gallery

1. Set `Config.ScreenshotWebhook` (or `Config.APIKeys.discord_webhook`).
2. Start `screenshot-basic`.
3. Open Camera → capture → photo lands in Gallery and can be attached to messages.

### Calls & messages

- Calls: dial, recents, favourites, mute, loudspeaker (`Config.OnLoudspeaker`), hold, hang up.
- Messages: threads, gallery attachments, location, emoji, groups (server data).
- Contacts: add, favourite, block, share number to nearby players (`Config.ShareDistance`).

### Bank / Crypto / Market / Business / News

- **Bank:** transfers to online numbers; history.
- **Crypto:** coins in `Config.Crypto`; interval `Config.CryptoUpdateMinutes`.
- **Market:** listings; limit `Config.MaxMarketPosts`.
- **Business:** duty, businesses, staff, hiring; limit `Config.MaxBusinesses`.
- **News:** publish if job is in `Config.NewsJobs`.

## 7. Languages

In-phone **ES · EN** toggle. Preference stored in the NUI browser.

## 8. Troubleshooting

| Issue | Check |
|-------|--------|
| Won’t open | Phone item, `Config.RequireItem`, client console |
| SQL / callbacks fail | `oxmysql` before resource; `sql/install.sql` imported |
| Framework error | `Config.Framework` and qb-core / es_extended started |
| Camera fails | Webhook in `config.lua` + `screenshot-basic` started |
| Calls with no audio | `Config.VoiceResource` and `setPlayerCall` export |
| Services empty | Exact job name + on-duty online players |
| `[iberic-phone]` errors | Server and client console |

## 9. Adding an app (developers)

1. Register in `APPS` (`html/app.js`).
2. Add id to `GRID` / `GRID_UNFOLD` or `DOCK`.
3. Implement `R.myapp = () => ...`.
4. Handle actions with `ACT.xxx` and `data-act`.
5. Add EN/ES strings at the bottom of `app.js`.
6. Persistent data: `CB('myapp:load', ...)` in `server/main.lua` + `api('myapp:load', ...)`.

**Never** trust citizen IDs, numbers, amounts or jobs from the NUI alone — always derive identity from the server-side player object.

---

## Quick config checklist

```lua
Config.Framework       = 'auto'
Config.PhoneItem       = 'phone'
Config.RequireItem     = true
Config.VoiceResource   = 'pma-voice'
Config.UploadProvider = 'fivemanage'
Config.APIKeys = { images = '...', audio = '...', video = '...', logs = '...' }
Config.ServiceContacts = { police = { label='Police', job='police', description='...' }, ... }
```

That’s everything needed to run Iberic Phone on ESX or QBCore with camera, calls, services and the dock torch.
