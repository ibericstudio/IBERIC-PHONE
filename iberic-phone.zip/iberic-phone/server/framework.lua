
-- Iberic framework bridge: QBCore native or ESX Legacy.
local Framework = (Config.Framework or 'auto'):lower()
QBCore = nil
local ESX

local function detect()
    if Framework ~= 'auto' then return Framework end
    if GetResourceState('qb-core') == 'started' then return 'qb' end
    if GetResourceState('es_extended') == 'started' then return 'esx' end
    return 'unknown'
end
Framework = detect()
if Framework == 'qb' then
    QBCore = exports['qb-core']:GetCoreObject()
elseif Framework == 'esx' then
    ESX = exports['es_extended']:getSharedObject()
    local function wrap(x)
        if not x then return nil end
        local job = x.getJob and x.getJob() or {}
        local first = x.get and (x.get('firstName') or x.get('firstname')) or ''
        local last = x.get and (x.get('lastName') or x.get('lastname')) or ''
        local phone = x.get and (x.get('phoneNumber') or x.get('phone')) or nil
        local grade = job.grade_label or tostring(job.grade or '')
        local metadata = {}
        if x.getMeta then metadata = x.getMeta() or {} end
        local p = {
            PlayerData = {
                source = x.source, citizenid = x.identifier, charinfo = {
                    firstname = first, lastname = last, phone = phone,
                    birthdate = x.get and x.get('dateofbirth') or '',
                    gender = x.get and x.get('sex') or '',
                    nationality = ''
                },
                job = { name = job.name or 'unemployed', label = job.label or 'Unemployed',
                    grade = { name = grade, level = tonumber(job.grade) or 0 },
                    payment = job.grade_salary or 0, onduty = job.onDuty == true, isboss = job.grade_name == 'boss' },
                metadata = metadata
            },
            Functions = {}
        }
        p.Functions.GetMoney = function(account)
            if account == 'bank' then
                local a = x.getAccount and x.getAccount('bank')
                return (a and a.money) or 0
            end
            return x.getMoney and x.getMoney() or 0
        end
        p.Functions.AddMoney = function(account, amount, reason)
            if account == 'bank' then return x.addAccountMoney('bank', amount, reason) end
            return x.addMoney(amount, reason)
        end
        p.Functions.RemoveMoney = function(account, amount, reason)
            if account == 'bank' then return x.removeAccountMoney('bank', amount, reason) end
            return x.removeMoney(amount, reason)
        end
        p.Functions.GetItemByName = function(item)
            if GetResourceState('ox_inventory') == 'started' then
                local count = exports.ox_inventory:Search(x.source, 'count', item) or 0
                if count > 0 then return { name = item, count = count } end
                return nil
            end
            local inv = x.getInventoryItem and x.getInventoryItem(item)
            return inv and (inv.count or inv.quantity or 0) > 0 and inv or nil
        end
        p.Functions.SetJobDuty = function(on)
            if Config.ESXSetJobDuty then return Config.ESXSetJobDuty(x, on) end
            return false
        end
        return p
    end
    QBCore = { Functions = {}, Shared = { Vehicles = {} } }
    QBCore.Functions.GetPlayer = function(src) return wrap(ESX.GetPlayerFromId(tonumber(src))) end
    QBCore.Functions.GetPlayerByCitizenId = function(identifier)
        for _, id in ipairs(ESX.GetPlayers()) do
            local x = ESX.GetPlayerFromId(id)
            if x and x.identifier == identifier then return wrap(x) end
        end
    end
    QBCore.Functions.GetQBPlayers = function()
        local out = {}
        for _, id in ipairs(ESX.GetPlayers()) do out[id] = wrap(ESX.GetPlayerFromId(id)) end
        return out
    end
    QBCore.Functions.CreateCallback = function(name, fn)
        ESX.RegisterServerCallback(name, function(src, cb, payload)
            local player = wrap(ESX.GetPlayerFromId(src))
            if not player then return cb(nil) end
            fn(src, cb, payload)
        end)
    end
    QBCore.Functions.CreateUseableItem = function(item, cb)
        ESX.RegisterUsableItem(item, function(src) cb(src) end)
    end
else
    error('[iberic-phone] Unsupported framework. Start qb-core or es_extended, or set Config.Framework to qb/esx.')
end

IbericFramework = Framework
