fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'iberic-phone'
author 'Iberic'
description 'Iberic Phone - ESX Legacy / QBCore'
version '1.2.0'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/framework.lua',
    'client/phone_anim.lua',
    'client/main.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/framework.lua',
    'server/main.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/wall-facet.svg',
    'html/fonts/*.ttf'
}

files {
    'stream/iberic_phone_ytyp.ytyp'
}
data_file 'DLC_ITYP_REQUEST' 'stream/iberic_phone_ytyp.ytyp'

dependencies {
    'oxmysql',
    'screenshot-basic', -- required for Camera (capture). Start it before iberic-phone.
}
