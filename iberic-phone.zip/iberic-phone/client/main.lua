-- QBCore compatibility facade is provided by client/framework.lua

local isOpen, inCamera, inCall, ringing = false, false, false, false
local dnd, airplane, isTyping = false, false, false

-- All phone-related feedback goes through the in-phone notification UI
local function PhoneNotify(title, text, app, force)
    SendNUIMessage({
        action = 'notify',
        notif = {
            title = title or 'Phone',
            text = text or '',
            app = app or 'settings',
            force = force and true or false,
        },
    })
end

local function getZone()
    local c = GetEntityCoords(PlayerPedId())
    local zone = GetLabelText(GetNameOfZone(c.x, c.y, c.z))
    local street = GetStreetNameFromHashKey((GetStreetNameAtCoord(c.x, c.y, c.z)))
    return zone, street
end

local function sendTick()
    local zone, street = getZone()
    SendNUIMessage({ action = 'tick', h = GetClockHours(), m = GetClockMinutes(), zone = zone, street = street })
end

local function uiConfig()
    return {
        wallpapers = Config.Wallpapers,
        currency = Config.Currency,
        realTime = Config.UseRealTime,
        services = Config.ServiceContacts or {},
    }
end

local function closePhone()
    if not isOpen then return end
    isOpen = false
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    SendNUIMessage({ action = 'close' })

    isTyping = false
    SetPhoneStates({ texting = false, open = false })
end

function IbericPhoneOnDeath()
    if isOpen then
        isOpen = false
        SetNuiFocus(false, false)
        SetNuiFocusKeepInput(false)
        isTyping = false
        SendNUIMessage({ action = 'close' })
    end
end

local function openPhone()
    if isOpen or inCamera then return end
    local pd = QBCore.Functions.GetPlayerData()
    if not pd or not pd.citizenid then return end
    if pd.metadata and (pd.metadata['isdead'] or pd.metadata['inlaststand'] or pd.metadata['ishandcuffed']) then return end
    if IsPauseMenuActive() then return end

    QBCore.Functions.TriggerCallback('iberic-phone:getAll', function(data)
        if not data then
            PhoneNotify('Phone', 'Failed to load. Check server console ([iberic-phone] / SQL).', 'settings', true)
            return
        end
        if data.noPhone then
            PhoneNotify('Phone', 'You do not have a phone', 'settings', true)
            return
        end
        if isOpen or inCamera then return end
        isOpen = true
        dnd = data.settings and data.settings.dnd or false
        airplane = data.settings and data.settings.airplane or false
        SetNuiFocus(true, true)
        -- Keep gameplay input active while the phone UI is open (walk/run/look).
        SetNuiFocusKeepInput(true)
        local zone, street = getZone()
        SendNUIMessage({
            action = 'open', data = data, cfg = uiConfig(),
            h = GetClockHours(), m = GetClockMinutes(), zone = zone, street = street,
        })
        SetPhoneState('open', true)
        CreateThread(function()
            while isOpen do
                sendTick()
                Wait(2000)
            end
        end)
    end)
end

RegisterCommand('ibericphone', function()
    if isOpen then closePhone() else openPhone() end
end, false)
RegisterKeyMapping('ibericphone', 'Open phone', 'keyboard', Config.OpenKey)

-- While the phone is open, keep walking controls available but lock mouse-look.
-- Hold LEFT ALT (control 19) to temporarily free the camera.
-- Block the standard GTA/FiveM text-chat controls so T cannot open chat over the phone.
CreateThread(function()
    local lastCameraFree = nil
    while true do
        if isOpen then
            if isTyping then
                -- Freeze the player while entering text in any phone input.
                DisableControlAction(0, 30, true) -- MoveLeftRight
                DisableControlAction(0, 31, true) -- MoveUpDown
                DisableControlAction(0, 21, true) -- Sprint
                DisableControlAction(0, 22, true) -- Jump
                DisableControlAction(0, 36, true) -- Duck
                DisableControlAction(0, 32, true)
                DisableControlAction(0, 33, true)
                DisableControlAction(0, 34, true)
                DisableControlAction(0, 35, true)
            end
            local cameraFree = IsControlPressed(0, 19) -- INPUT_CHARACTER_WHEEL / LEFT ALT
            if not cameraFree then
                DisableControlAction(0, 1, true) -- LookLeftRight
                DisableControlAction(0, 2, true) -- LookUpDown
            end

            DisableControlAction(0, 245, true) -- INPUT_MP_TEXT_CHAT_ALL (T)
            DisableControlAction(0, 246, true) -- INPUT_MP_TEXT_CHAT_TEAM
            DisableControlAction(0, 24, true)  -- Attack
            DisableControlAction(0, 25, true)  -- Aim
            DisableControlAction(0, 37, true)  -- Weapon wheel
            DisableControlAction(0, 44, true)  -- Cover
            DisableControlAction(0, 140, true) -- Melee
            DisableControlAction(0, 141, true)
            DisableControlAction(0, 142, true)
            DisableControlAction(0, 143, true)

            if lastCameraFree ~= cameraFree then
                lastCameraFree = cameraFree
                SendNUIMessage({ action = 'cameraMode', free = cameraFree })
            end
            Wait(0)
        else
            if lastCameraFree ~= nil then
                lastCameraFree = nil
                SendNUIMessage({ action = 'cameraMode', free = false })
            end
            Wait(350)
        end
    end
end)

RegisterCommand('phone', function()
    if isOpen then closePhone() else openPhone() end
end, false)

AddEventHandler('onClientResourceStart', function(res)
    if res ~= GetCurrentResourceName() then return end
    print(('[iberic-phone] client started. Key: %s | require item: %s (%s)'):format(Config.OpenKey, tostring(Config.RequireItem), Config.PhoneItem))
end)

RegisterNetEvent('iberic-phone:client:open', openPhone)

RegisterNUICallback('close', function(_, cb)
    cb({})
    closePhone()
end)

RegisterNUICallback('fold', function(data, cb)
    cb({})
    SetPhoneFolded(data and data.open)
end)

RegisterNUICallback('inputFocus', function(data, cb)
    cb({})
    if not isOpen then return end
    isTyping = data and data.focused and true or false
    SetPhoneState('texting', isTyping)
end)

RegisterNUICallback('cb', function(data, cb)
    if type(data) ~= 'table' or type(data.name) ~= 'string' then return cb({}) end
    QBCore.Functions.TriggerCallback('iberic-phone:' .. data.name, function(res)
        cb(res == nil and {} or res)
    end, data.payload or {})
end)

RegisterNUICallback('sync', function(data, cb)
    dnd = data and data.dnd and true or false
    airplane = data and data.airplane and true or false
    cb({})
end)

RegisterNUICallback('answer', function(_, cb)
    cb({})
    ringing = false
    TriggerServerEvent('iberic-phone:server:answer')
end)

RegisterNUICallback('callhold', function(_, cb)
    cb({})
    TriggerServerEvent('iberic-phone:server:hold')
end)

RegisterNUICallback('callopt', function(d, cb)
    cb({})
    if d and d.kind == 'mute' then
        pcall(NetworkSetVoiceActive, not d.on)
    elseif d and d.kind == 'speaker' and Config.OnLoudspeaker then
        pcall(Config.OnLoudspeaker, d.on and true or false)
    end
end)

RegisterNUICallback('hangup', function(_, cb)
    cb({})
    ringing = false
    TriggerServerEvent('iberic-phone:server:hangup')
end)

-- Dock flashlight: real world light from the player (spot + fill)
local torchOn = false
RegisterNUICallback('torch', function(d, cb)
    cb({})
    torchOn = d and d.on and true or false
    SetFlashLightKeepOnWhileMoving(torchOn)
    SetFlashLightFadeDistance(torchOn and 45.0 or 0.0)
    if torchOn then
        PhoneNotify('Torch', 'Torch ON', 'settings')
    else
        PhoneNotify('Torch', 'Torch OFF', 'settings')
    end
end)

CreateThread(function()
    while true do
        if torchOn then
            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)
            local forward = GetEntityForwardVector(ped)
            local head = GetPedBoneCoords(ped, 31086, 0.0, 0.0, 0.0) -- SKEL_Head
            local ox, oy, oz = head.x, head.y, head.z + 0.12
            -- Main beam in look direction
            DrawSpotLight(
                ox, oy, oz,
                forward.x, forward.y, forward.z,
                255, 245, 220,
                28.0, -- distance
                8.0,  -- brightness
                0.0,  -- roundness
                18.0, -- radius
                1.0   -- falloff
            )
            -- Soft fill near the player so the area is actually lit
            DrawLightWithRange(ox + forward.x * 1.2, oy + forward.y * 1.2, oz, 255, 240, 210, 12.0, 1.4)
            Wait(0)
        else
            Wait(400)
        end
    end
end)

local function extractImageUrl(decoded)
    if type(decoded) ~= 'table' then return nil end
    if decoded.data and type(decoded.data) == 'table' and decoded.data.url and decoded.data.url ~= '' then
        return decoded.data.url
    end
    if decoded.url and decoded.url ~= '' then return decoded.url end
    if decoded.attachments and decoded.attachments[1] and decoded.attachments[1].url then
        return decoded.attachments[1].url
    end
    return nil
end

-- Primary path: server asks for a client screenshot and uploads to Fivemanage (API key stays on server).
-- Fallback: client-side screenshot-basic upload if the server path is unavailable.
local function takePhoto()
    PlaySoundFrontend(-1, 'Camera_Shoot', 'Phone_SoundSet_Default', true)
    PhoneNotify('Camera', 'Saving photo…', 'camera')
    TriggerServerEvent('iberic-phone:server:capturePhoto')
end

-- Client fallback used when the server asks the client to upload directly
RegisterNetEvent('iberic-phone:client:captureFallback', function()
    local provider = (Config.UploadProvider or 'fivemanage'):lower()
    if provider == 'fivemanage' then
        local apiKey = Config.APIKeys and Config.APIKeys.images or ''
        if apiKey == '' then
            PhoneNotify('Camera', 'Missing Config.APIKeys.images', 'camera', true)
            return
        end
        local uploadUrl = Config.FivemanageUploadUrl or 'https://api.fivemanage.com/api/v3/file'
        local field = Config.FivemanageField or 'file'
        local function onUpload(res)
            local decoded = json.decode(res or '{}') or {}
            local url = extractImageUrl(decoded)
            if url then
                TriggerServerEvent('iberic-phone:server:addPhoto', url)
                PhoneNotify('Camera', 'Photo saved to gallery', 'camera')
            else
                print(('[iberic-phone] Fivemanage client upload: %s'):format(tostring(res)))
                PhoneNotify('Camera', 'Upload failed', 'camera', true)
            end
        end
        local ok = pcall(function()
            exports['screenshot-basic']:requestScreenshotUpload(uploadUrl, field, {
                headers = { Authorization = apiKey },
                encoding = 'jpg',
            }, onUpload)
        end)
        if not ok then
            local ok2 = pcall(function()
                local urlWithKey = uploadUrl .. '?apiKey=' .. apiKey
                exports['screenshot-basic']:requestScreenshotUpload(urlWithKey, field, { encoding = 'jpg' }, onUpload)
            end)
            if not ok2 then
                PhoneNotify('Camera', 'screenshot-basic is not running. Install & ensure it.', 'camera', true)
            end
        end
        return
    end
    local webhook = Config.ScreenshotWebhook or ''
    if webhook == '' then
        PhoneNotify('Camera', 'Camera not configured', 'camera', true)
        return
    end
    local ok = pcall(function()
        exports['screenshot-basic']:requestScreenshotUpload(webhook, Config.ScreenshotField or 'files[]', function(res)
            local decoded = json.decode(res or '{}') or {}
            local url = extractImageUrl(decoded)
            if url then
                TriggerServerEvent('iberic-phone:server:addPhoto', url)
                PhoneNotify('Camera', 'Photo saved to gallery', 'camera')
            else
                PhoneNotify('Camera', 'Upload failed', 'camera', true)
            end
        end)
    end)
    if not ok then PhoneNotify('Camera', 'screenshot-basic is not running', 'camera', true) end
end)

RegisterNetEvent('iberic-phone:client:photoResult', function(ok, msg)
    if ok then
        PhoneNotify('Camera', msg or 'Photo saved to gallery', 'camera')
    else
        PhoneNotify('Camera', msg or 'Photo failed', 'camera', true)
    end
end)

local function startCamera()
    if inCamera then return end
    inCamera = true
    closePhone()
    local selfie = false
    DestroyMobilePhone()
    CreateMobilePhone(0)
    CellCamActivate(true, true)
    DisplayRadar(false)
    CreateThread(function()
        while inCamera do
            HideHudComponentThisFrame(7)
            HideHudComponentThisFrame(8)
            HideHudComponentThisFrame(9)
            HideHudComponentThisFrame(6)
            HideHudComponentThisFrame(19)
            if IsControlJustPressed(0, 177) then
                inCamera = false
            elseif IsControlJustPressed(0, 191) then
                takePhoto()
            elseif IsControlJustPressed(0, 172) then
                selfie = not selfie
                CellCamActivateSelfieMode(selfie)
            end
            Wait(0)
        end
        CellCamActivate(false, false)
        DestroyMobilePhone()
        DisplayRadar(true)
        Wait(150)
        openPhone()
    end)
end

RegisterNUICallback('camera', function(_, cb)
    cb({})
    startCamera()
end)

RegisterNetEvent('iberic-phone:client:photoSaved', function(gallery)
    SendNUIMessage({ action = 'gallery', gallery = gallery })
end)

RegisterNetEvent('iberic-phone:client:newMessage', function(msg)
    SendNUIMessage({ action = 'newMessage', msg = msg })
    if not dnd then
        PlaySoundFrontend(-1, 'Text_Arrive_Tone', 'Phone_SoundSet_Default', true)
    end
end)

RegisterNetEvent('iberic-phone:client:notify', function(n)
    SendNUIMessage({ action = 'notify', notif = n })
    if not dnd then
        PlaySoundFrontend(-1, 'Text_Arrive_Tone', 'Phone_SoundSet_Default', true)
    end
end)

RegisterNetEvent('iberic-phone:client:groups', function(groups)
    SendNUIMessage({ action = 'groups', groups = groups })
end)

RegisterNUICallback('coords', function(_, cb)
    local c = GetEntityCoords(PlayerPedId())
    cb({ loc = ('%.2f,%.2f'):format(c.x, c.y) })
end)

RegisterNUICallback('waypoint', function(d, cb)
    cb({})
    local x, y = tostring(d and d.loc or ''):match('^(%-?%d+%.?%d*),(%-?%d+%.?%d*)$')
    if x then
        SetNewWaypoint(tonumber(x) + 0.0, tonumber(y) + 0.0)
        PhoneNotify('Messages', 'Waypoint set', 'messages')
    end
end)

RegisterNetEvent('iberic-phone:client:shared', function(shared, from)
    SendNUIMessage({ action = 'shared', shared = shared, from = from })
    if not dnd then
        PlaySoundFrontend(-1, 'Text_Arrive_Tone', 'Phone_SoundSet_Default', true)
    end
end)

RegisterNetEvent('iberic-phone:client:incomingCall', function(d)
    sendTick()
    SendNUIMessage({ action = 'incomingCall', id = d.id, number = d.number })
    if dnd or airplane then return end
    ringing = true
    CreateThread(function()
        while ringing do
            PlaySoundFrontend(-1, 'Remote_Ring', 'Phone_SoundSet_Michael', true)
            local untilT = GetGameTimer() + 3000
            while ringing and GetGameTimer() < untilT do
                if not isOpen then
                    if IsControlJustPressed(0, 246) or IsControlJustPressed(0, 191) then
                        ringing = false
                        TriggerServerEvent('iberic-phone:server:answer')
                    elseif IsControlJustPressed(0, 306) or IsControlJustPressed(0, 177) then
                        ringing = false
                        TriggerServerEvent('iberic-phone:server:hangup')
                    end
                end
                Wait(0)
            end
        end
    end)
end)

RegisterNetEvent('iberic-phone:client:callAnswered', function(id)
    ringing = false
    inCall = true
    SendNUIMessage({ action = 'callAnswered', id = id })
    SetPhoneState('call', true)
end)

RegisterNetEvent('iberic-phone:client:callHold', function(on)
    SendNUIMessage({ action = 'callHold', on = on })
end)

RegisterNetEvent('iberic-phone:client:callEnded', function(reason)
    ringing = false
    inCall = false
    pcall(NetworkSetVoiceActive, true)
    SendNUIMessage({ action = 'callEnded', reason = reason })
    SetPhoneState('call', false)
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    SetNuiFocus(false, false)
    ResetPhoneAnim()
    if inCamera then
        CellCamActivate(false, false)
        DestroyMobilePhone()
        DisplayRadar(true)
    end
end)

RegisterNetEvent('QBCore:Client:OnPlayerUnload', function()
    if isOpen then closePhone() end
end)

exports('IsPhoneOpen', function() return isOpen end)
