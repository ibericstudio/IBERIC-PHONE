
-- Iberic framework bridge for QBCore and ESX Legacy.
local Framework = (Config.Framework or 'auto'):lower()
QBCore = nil
local ESX
if Framework == 'auto' then
    if GetResourceState('qb-core') == 'started' then Framework = 'qb'
    elseif GetResourceState('es_extended') == 'started' then Framework = 'esx'
    else Framework = 'unknown' end
end
if Framework == 'qb' then
    QBCore = exports['qb-core']:GetCoreObject()
elseif Framework == 'esx' then
    ESX = exports['es_extended']:getSharedObject()
    QBCore = { Functions = {} }
    QBCore.Functions.GetPlayerData = function()
        local d = ESX.GetPlayerData() or {}
        local job = d.job or {}
        local metadata = d.metadata or {}
        local state = LocalPlayer and LocalPlayer.state or {}
        metadata.isdead = metadata.isdead or d.dead or d.isDead or state.isDead
        metadata.inlaststand = metadata.inlaststand or d.lastStand or state.inLastStand
        metadata.ishandcuffed = metadata.ishandcuffed or d.handcuffed or state.handcuffed
        return {
            citizenid = d.identifier,
            metadata = metadata,
            job = { name = job.name, label = job.label, onduty = job.onDuty },
            charinfo = { firstname = d.firstName or '', lastname = d.lastName or '' }
        }
    end
    QBCore.Functions.TriggerCallback = function(name, cb, payload)
        ESX.TriggerServerCallback(name, cb, payload)
    end
    QBCore.Functions.Notify = function(message, kind, duration)
        ESX.ShowNotification(message)
    end
else
    error('[iberic-phone] Unsupported framework. Start qb-core or es_extended, or set Config.Framework to qb/esx.')
end
IbericFramework = Framework
